package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ReelEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reelDao(): ReelDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "reels_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                try {
                    INSTANCE?.let { database ->
                        populateDatabase(database.reelDao())
                    }
                } catch (e: Exception) {
                    android.util.Log.e("AppDatabase", "Exception during initial database population", e)
                }
            }
        }

        suspend fun populateDatabase(reelDao: ReelDao) {
            // Check if we already have data
            if (reelDao.getCount() == 0) {
                val initialReels = listOf(
                    ReelEntity(
                        username = "JetpackComposer",
                        description = "Building ultra-realistic ripple touch effects in Jetpack Compose was never this easy with Material 3! 🚀 #androidDev #jetpackcompose #m3 #ux",
                        likes = 1420,
                        isLiked = false,
                        category = "Compose",
                        commentsCount = 84,
                        sharesCount = 28
                    ),
                    ReelEntity(
                        username = "AI_Studio_Builder",
                        description = "Generating an entire interactive video reels application using Gemini and a multi-agent coder workspace. Absolute magic! ✨ #coding #gemini #fullstack #agentic",
                        likes = 2589,
                        isLiked = true,
                        category = "Gemini",
                        commentsCount = 192,
                        sharesCount = 67
                    ),
                    ReelEntity(
                        username = "KotlinExplorer",
                        description = "Did you know Kotlin Coroutines flows can emit live states reactively to Jetpack Compose UI sheets? Here is a 10s concept. 📱 #kotlin #programming #flow",
                        likes = 841,
                        isLiked = false,
                        category = "Kotlin",
                        commentsCount = 37,
                        sharesCount = 11
                    ),
                    ReelEntity(
                        username = "TechBytes",
                        description = "The future of mobile displays: micro-LED, foldables, and rollables! Which one are you choosing for your next pocket powerhouse? 🤖 #mobile #hardware #screens",
                        likes = 907,
                        isLiked = false,
                        category = "Tech News",
                        commentsCount = 59,
                        sharesCount = 24
                    ),
                    ReelEntity(
                        username = "DesignInMotion",
                        description = "Asymmetric visual layout styles and glassmorphism overlay cards. Say goodbye to plain AI slop, embracing bold typography decisions! 🎨 #uidesign #craftsmanship",
                        likes = 1115,
                        isLiked = false,
                        category = "UI Design",
                        commentsCount = 76,
                        sharesCount = 42
                    )
                )
                reelDao.insertAll(initialReels)
            }
        }
    }
}
