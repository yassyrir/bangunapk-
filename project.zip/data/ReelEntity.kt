package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reels")
data class ReelEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val description: String,
    val likes: Int,
    val isLiked: Boolean = false,
    val category: String = "Design",
    val commentsCount: Int = 42,
    val sharesCount: Int = 7
)
