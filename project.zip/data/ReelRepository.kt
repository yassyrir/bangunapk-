package com.example.data

import kotlinx.coroutines.flow.Flow

class ReelRepository(private val reelDao: ReelDao) {
    val allReels: Flow<List<ReelEntity>> = reelDao.getAllReels()

    suspend fun insert(reel: ReelEntity): Long {
        return reelDao.insertReel(reel)
    }

    suspend fun update(reel: ReelEntity) {
        reelDao.updateReel(reel)
    }

    suspend fun delete(reel: ReelEntity) {
        reelDao.deleteReel(reel)
    }
}
