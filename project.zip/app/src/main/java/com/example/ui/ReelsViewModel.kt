package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.CommentsResult
import com.example.api.GeminiReelService
import com.example.api.GeneratedComment
import com.example.api.ReelItemResult
import com.example.data.AppDatabase
import com.example.data.ReelEntity
import com.example.data.ReelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class ReelsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReelRepository
    val allReels: StateFlow<List<ReelEntity>>

    private val _comments = MutableStateFlow<List<GeneratedComment>>(emptyList())
    val comments: StateFlow<List<GeneratedComment>> = _comments.asStateFlow()

    private val _commentsLoading = MutableStateFlow(false)
    val commentsLoading: StateFlow<Boolean> = _commentsLoading.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _generationStatus = MutableStateFlow<String?>(null)
    val generationStatus: StateFlow<String?> = _generationStatus.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = ReelRepository(database.reelDao())
        allReels = repository.allReels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // Toggle Suka / Like
    fun toggleLike(reel: ReelEntity) {
        viewModelScope.launch {
            val updatedReel = reel.copy(
                isLiked = !reel.isLiked,
                likes = if (reel.isLiked) reel.likes - 1 else reel.likes + 1
            )
            repository.update(updatedReel)
        }
    }

    // Increments share and returns shared caption text
    fun shareReel(reel: ReelEntity): String {
        viewModelScope.launch {
            val updatedReel = reel.copy(sharesCount = reel.sharesCount + 1)
            repository.update(updatedReel)
        }
        return "Check this cool reel by @${reel.username}!\n\"${reel.description}\"\nShared via Android Reels Player ✨"
    }

    // Fetch comments via Gemini dynamically for the visible Reel
    fun fetchCommentsForReel(reel: ReelEntity) {
        viewModelScope.launch {
            _commentsLoading.value = true
            _comments.value = emptyList()
            when (val result = GeminiReelService.generateComments(reel.description)) {
                is CommentsResult.Success -> {
                    _comments.value = result.comments
                }
                is CommentsResult.Fallback -> {
                    _comments.value = result.comments
                }
            }
            _commentsLoading.value = false
        }
    }

    // User adding local custom comments
    fun addLocalComment(text: String, author: String = "you_explorer") {
        val newList = _comments.value.toMutableList()
        newList.add(0, GeneratedComment(username = author, text = text, likes = 0))
        _comments.value = newList
    }

    // Generate new Reel with AI topic
    fun generateNewReel(topic: String, onFinished: (Int) -> Unit = {}) {
        viewModelScope.launch {
            _isGenerating.value = true
            _generationStatus.value = "Consulting Gemini for creative ideas about '$topic'..."
            
            when (val result = GeminiReelService.generateReel(topic)) {
                is ReelItemResult.Success -> {
                    val newId = repository.insert(result.reel)
                    _isGenerating.value = false
                    _generationStatus.value = "Reel generated perfectly!"
                    onFinished(newId.toInt())
                }
                is ReelItemResult.Fallback -> {
                    val newId = repository.insert(result.reel)
                    _isGenerating.value = false
                    _generationStatus.value = "Key status: Offline fallback active. Reel added."
                    onFinished(newId.toInt())
                }
            }
        }
    }

    // Manual Creation from form
    fun createManualReel(username: String, description: String, category: String, onFinished: (Int) -> Unit) {
        viewModelScope.launch {
            val reel = ReelEntity(
                username = username.lowercase().replace(" ", ""),
                description = description,
                category = category,
                likes = Random.nextInt(10, 500),
                commentsCount = 0,
                sharesCount = 0
            )
            val newId = repository.insert(reel)
            onFinished(newId.toInt())
        }
    }

    // Delete a reel
    fun deleteReel(reel: ReelEntity) {
        viewModelScope.launch {
            repository.delete(reel)
        }
    }

    fun clearStatus() {
        _generationStatus.value = null
    }
}
