package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ReelEntity
import com.example.api.GeneratedComment
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AndroidReelsScreen(viewModel: ReelsViewModel) {
    val reelsList by viewModel.allReels.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val generationStatus by viewModel.generationStatus.collectAsState()

    val pagerState = rememberPagerState(pageCount = { reelsList.size })
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Sheets & Modals state
    var showCommentsSheet by remember { mutableStateOf<ReelEntity?>(null) }
    var showAiIdeatorModal by remember { mutableStateOf(false) }
    var showManualCreateModal by remember { mutableStateOf(false) }

    // Observe active page to fetch comments reactively
    LaunchedEffect(pagerState.currentPage, reelsList) {
        if (reelsList.isNotEmpty() && pagerState.currentPage < reelsList.size) {
            val activeReel = reelsList[pagerState.currentPage]
            viewModel.fetchCommentsForReel(activeReel)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)) // Slate-900 background
    ) {
        if (reelsList.isEmpty()) {
            // Loading/Empty State
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Preparing Reels Terminal...",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            // Immersive Reels Pager
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                if (page < reelsList.size) {
                    val reel = reelsList[page]
                    ReelCardItem(
                        reel = reel,
                        onLikeToggle = { viewModel.toggleLike(reel) },
                        onCommentsClick = { showCommentsSheet = reel },
                        onShareClick = {
                            val shareText = viewModel.shareReel(reel)
                            clipboardManager.setText(AnnotatedString(shareText))
                            Toast.makeText(context, "Caption copied to clipboard! ✨", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteClick = {
                            if (reelsList.size > 1) {
                                viewModel.deleteReel(reel)
                                Toast.makeText(context, "Reel deleted.", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Cannot delete the last remaining reel!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }

        // Top Navigation & Action Panel
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "REELS PLAYER",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    letterSpacing = 1.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF10B981), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE ATMOSPHERE",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Quick Actions (AI Ideator & Create Manual)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showAiIdeatorModal = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6D28D9), // Intense purple
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("ai_ideator_btn")
                ) {
                    Icon(
                        Icons.Default.Star, 
                        contentDescription = "AI Idea", 
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI Setup", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showManualCreateModal = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E293B),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("create_reel_btn")
                ) {
                    Icon(
                        Icons.Default.Add, 
                        contentDescription = "Create", 
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Bottom Sheets and Overlays for loading
        if (showAiIdeatorModal) {
            AiIdeatorModal(
                onDismiss = { showAiIdeatorModal = false },
                onGenerate = { topic ->
                    viewModel.generateNewReel(topic) { newId ->
                        // Scroll to the newly added reel if any
                        coroutineScope.launch {
                            val index = reelsList.indexOfFirst { it.id == newId }
                            if (index >= 0) {
                                pagerState.animateScrollToPage(index)
                            }
                        }
                    }
                }
            )
        }

        if (showManualCreateModal) {
            CreateReelModal(
                onDismiss = { showManualCreateModal = false },
                onCreate = { user, desc, cat ->
                    viewModel.createManualReel(user, desc, cat) { newId ->
                        coroutineScope.launch {
                            val index = reelsList.indexOfFirst { it.id == newId }
                            if (index >= 0) {
                                pagerState.animateScrollToPage(index)
                            }
                        }
                    }
                }
            )
        }

        // Loading overlay for Gemini generator
        if (isGenerating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2E)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(16.dp)
                        .border(1.dp, Color(0xFF6D28D9).copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF8B5CF6),
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "GEMINI CO-WRITING",
                            color = Color(0xFF8B5CF6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = generationStatus ?: "Composing dynamic layout...",
                            color = Color.White,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "This integrates standard artificial intelligence pipelines for true client creativity.",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Comments Bottom Sheet
        if (showCommentsSheet != null) {
            ModalBottomSheet(
                onDismissRequest = { showCommentsSheet = null },
                containerColor = Color(0xFF0F172A),
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ) {
                CommentSectionSheet(
                    reel = showCommentsSheet!!,
                    viewModel = viewModel,
                    onClose = { showCommentsSheet = null }
                )
            }
        }
    }
}

@Composable
fun ReelCardItem(
    reel: ReelEntity,
    onLikeToggle: () -> Unit,
    onCommentsClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var doubleTapLikedTrigger by remember { mutableStateOf(false) }

    // Disk Rotation state
    val infiniteTransition = rememberInfiniteTransition(label = "music_rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(reel.id) {
                detectTapGestures(
                    onDoubleTap = {
                        doubleTapLikedTrigger = true
                        if (!reel.isLiked) {
                            onLikeToggle()
                        }
                    }
                )
            }
    ) {
        // High fidelity custom animated atmosphere to simulate rich dynamic video
        SimulatedVideoBackground(category = reel.category)

        // Reset heart burst after brief interval
        LaunchedEffect(doubleTapLikedTrigger) {
            if (doubleTapLikedTrigger) {
                delay(800)
                doubleTapLikedTrigger = false
            }
        }

        // Floating Double Tap Heart Overlay
        AnimatedVisibility(
            visible = doubleTapLikedTrigger,
            enter = scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = "Sparks Liked",
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(110.dp)
            )
        }

        // Bottom Gradient shadows to ensure high readability
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.35f)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                    )
                )
        )

        // Contents and Overlay Panels
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // Details description card
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
            ) {
                // Category Chip Tag
                Box(
                    modifier = Modifier
                        .background(Color(0xFF8B5CF6).copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = reel.category.uppercase(),
                        color = Color(0xFFC084FC),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "@${reel.username}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = reel.description,
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Equilizer sound tracks
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Live Sound",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Music Track - Original Audio (@${reel.username})",
                        color = Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.SansSerif
                    )
                }
            }

            // Quick Controller sidebar
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                // Profile avatar indicator with gradient spinner ring
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .border(2.dp, Color(0xFF8B5CF6), CircleShape)
                        .padding(3.dp)
                        .background(Color(0xFF1E293B), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = reel.username.take(2).uppercase(),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Heart Button
                val heartScale by animateFloatAsState(
                    targetValue = if (reel.isLiked) 1.25f else 1.0f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy),
                    label = "heart_scale"
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onLikeToggle,
                        modifier = Modifier
                            .scale(heartScale)
                            .size(44.dp)
                            .testTag("like_btn_${reel.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Favorite,
                            contentDescription = "Suka/Disukai",
                            tint = if (reel.isLiked) Color(0xFFEF4444) else Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Text(text = "${reel.likes}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Comment Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onCommentsClick,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("comment_btn_${reel.id}")
                    ) {
                        CommentIconCustom(color = Color.White, size = 26.dp)
                    }
                    Text(text = "${reel.commentsCount}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Share Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onShareClick,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("share_btn_${reel.id}")
                    ) {
                        Icon(
                            Icons.Filled.Share,
                            contentDescription = "Bagikan",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Text(text = "${reel.sharesCount}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Delete Custom Button
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Red.copy(alpha = 0.15f), CircleShape)
                        .border(1.dp, Color.Red.copy(alpha = 0.3f), CircleShape)
                ) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = "Delete Local",
                        tint = Color(0xFFF87171),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Mini revolving disc spinning
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .rotate(rotationAngle)
                        .border(3.dp, Color(0xFF334155), CircleShape)
                        .background(Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF8B5CF6), CircleShape)
                    )
                }
            }
        }
    }
}

@Composable
fun CommentIconCustom(color: Color, size: androidx.compose.ui.unit.Dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Outer bubble frame
        val bubblePath = Path().apply {
            moveTo(w * 0.15f, h * 0.15f)
            lineTo(w * 0.85f, h * 0.15f)
            lineTo(w * 0.85f, h * 0.65f)
            lineTo(w * 0.45f, h * 0.65f)
            lineTo(w * 0.22f, h * 0.85f)
            lineTo(w * 0.22f, h * 0.65f)
            lineTo(w * 0.15f, h * 0.65f)
            close()
        }
        drawPath(
            path = bubblePath,
            color = color,
            style = Stroke(width = 2.dp.toPx())
        )

        // Triple audio/text lines representing chat inside bubble
        drawLine(
            color = color,
            start = Offset(w * 0.32f, h * 0.32f),
            end = Offset(w * 0.68f, h * 0.32f),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            color = color,
            start = Offset(w * 0.32f, h * 0.48f),
            end = Offset(w * 0.58f, h * 0.48f),
            strokeWidth = 2.dp.toPx()
        )
    }
}

// Simulated dynamic short form videos based on dynamic math waves & color codes.
@Composable
fun SimulatedVideoBackground(category: String) {
    val transition = rememberInfiniteTransition(label = "simulated_motion")
    val ticker by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "math_ticker"
    )

    // Set colors based on chosen category to create authentic environments
    val (color1, color2, color3) = when (category.lowercase()) {
        "compose", "jetpack" -> Triple(Color(0xFF1E1E38), Color(0xFF3B0764), Color(0xFF0369A1)) // Indigo to Dark Blue
        "gemini", "ai" -> Triple(Color(0xFF0F172A), Color(0xFF020617), Color(0xFF581C87)) // Deep Space to Dark Indigo
        "kotlin" -> Triple(Color(0xFF451A03), Color(0xFF7C2D12), Color(0xFF9D174D)) // Dark Orange to Rosewood
        "ui design", "design" -> Triple(Color(0xFF162521), Color(0xFF0D1F2D), Color(0xFF500073)) // Jade to luxury slate
        else -> Triple(Color(0xFF180020), Color(0xFF04021E), Color(0xFF2E0854)) // Cosmic darkviolet
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Draw luxury smooth background gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(color1, color2, color3)
                )
            )

            // Dynamic algorithmic art rendering
            val centerH = size.height / 2f
            val centerW = size.width / 2f

            // Sine Wave 1 (Subtle atmospheric lines)
            val path1 = Path()
            path1.moveTo(0f, centerH)
            for (x in 0..size.width.toInt() step 10) {
                val dx = x.toFloat()
                val dy = centerH + sin(dx * 0.007f + ticker) * 120f
                path1.lineTo(dx, dy)
            }
            drawPath(
                path = path1,
                color = color3.copy(alpha = 0.25f),
                style = Stroke(width = 4.dp.toPx())
            )

            // Sine Wave 2 (Contrasting cross line)
            val path2 = Path()
            path2.moveTo(0f, centerH + 100f)
            for (x in 0..size.width.toInt() step 10) {
                val dx = x.toFloat()
                val dy = (centerH + 140f) + sin(dx * 0.005f - ticker) * 70f
                path2.lineTo(dx, dy)
            }
            drawPath(
                path = path2,
                color = Color(0xFF10B981).copy(alpha = 0.15f),
                style = Stroke(width = 3.dp.toPx())
            )

            // Dynamic Floating Particles
            for (i in 0..20) {
                val randomX = (i * 357 + 45) % size.width
                val driftY = (size.height + (i * 121 + ticker * 150)) % size.height
                val radius = (i % 4 + 2) * 2.dp.toPx()
                val alpha = (0.2f + 0.3f * sin(ticker + i.toFloat()))
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = radius,
                    center = Offset(randomX, size.height - driftY)
                )
            }
        }
    }
}

@Composable
fun CommentSectionSheet(
    reel: ReelEntity,
    viewModel: ReelsViewModel,
    onClose: () -> Unit
) {
    val commentsList by viewModel.comments.collectAsState()
    val commentsLoading by viewModel.commentsLoading.collectAsState()
    var userCommentText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.75f)
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Drag Indicator handle
        Box(
            modifier = Modifier
                .width(42.dp)
                .height(4.dp)
                .background(Color(0xFF334155), RoundedCornerShape(2.dp))
                .align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Title Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Comments Section",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "AI-generated on demand by Gemini 🤖",
                    color = Color(0xFF8B5CF6),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier.background(Color(0xFF1E293B), CircleShape)
            ) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "Dismiss comments",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Divider(
            modifier = Modifier.padding(vertical = 12.dp),
            color = Color(0xFF334155),
            thickness = 0.5.dp
        )

        // List Scroll Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            if (commentsLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = Color(0xFF8B5CF6))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Gemini is analysing caption vibe...",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                }
            } else if (commentsList.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "No comments yet.\nBe the first to comment!",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(commentsList) { comment ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            // User Icon Circle
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(Color(0xFF1E293B), CircleShape)
                                    .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = comment.username.take(2).uppercase(),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Comment text card
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "@${comment.username}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "viewer",
                                        color = Color(0xFF8B5CF6).copy(alpha = 0.8f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .background(
                                                Color(0xFF8B5CF6).copy(alpha = 0.12f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = comment.text,
                                    color = Color.LightGray,
                                    fontSize = 13.sp,
                                    lineHeight = 16.sp
                                )
                            }

                            // Heart feedback like count
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(start = 8.dp)
                            ) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = "Comment likes",
                                    tint = Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${comment.likes}",
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Reply Keyboard Input Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            color = Color.Transparent
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = userCommentText,
                    onValueChange = { userCommentText = it },
                    placeholder = { Text("Comment on '@${reel.username}'...", color = Color.White.copy(alpha = 0.4f)) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("comment_input_box"),
                    maxLines = 3
                )

                IconButton(
                    onClick = {
                        if (userCommentText.trim().isNotEmpty()) {
                            viewModel.addLocalComment(userCommentText.trim())
                            userCommentText = ""
                        }
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .background(Color(0xFF8B5CF6), CircleShape)
                        .testTag("send_comment_btn"),
                    enabled = userCommentText.trim().isNotEmpty()
                ) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AiIdeatorModal(
    onDismiss: () -> Unit,
    onGenerate: (String) -> Unit
) {
    var customKeyword by remember { mutableStateOf("") }
    val suggestionList = listOf("Coding Memes", "AI Future-Shock", "Compose Ripple Effects", "Cat Developer Hacks", "Mountain Hiker Coffee")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, contentDescription = "AI Action", tint = Color(0xFFFBBF24))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gemini Reels Writer", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Request Gemini to generate a creative script, hashtags, and realistic likes for a brand-new custom topic!",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )

                OutlinedTextField(
                    value = customKeyword,
                    onValueChange = { customKeyword = it },
                    label = { Text("Enter Topic/Keyword") },
                    placeholder = { Text("e.g. Kotlin flow tricks...") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF8B5CF6),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedLabelColor = Color(0xFF8B5CF6),
                        unfocusedLabelColor = Color.LightGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("topic_input")
                )

                Text(
                    text = "Quick Presets:",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                // Hot presets buttons
                FlowLayout(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalGap = 6.dp,
                    verticalGap = 6.dp
                ) {
                    suggestionList.forEach { keyword ->
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                                .clickable { customKeyword = keyword }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(text = keyword, color = Color.LightGray, fontSize = 10.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val topic = customKeyword.ifEmpty { suggestionList.random() }
                    onGenerate(topic)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9)),
                modifier = Modifier.testTag("submit_topic_btn")
            ) {
                Text("Compose AI Reel")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.LightGray)
            }
        },
        containerColor = Color(0xFF1E1E2E),
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun CreateReelModal(
    onDismiss: () -> Unit,
    onCreate: (String, String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Tech") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Create Custom Reel", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username Handle") },
                    placeholder = { Text("e.g. android_pro") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF8B5CF6),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Caption Description") },
                    placeholder = { Text("Explain or tell something cool...") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF8B5CF6),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category Token") },
                    placeholder = { Text("e.g. Fun, Food, Music") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF8B5CF6),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (username.isNotEmpty() && description.isNotEmpty()) {
                        onCreate(username, description, category.ifEmpty { "General" })
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
            ) {
                Text("Insert Reel")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.LightGray)
            }
        },
        containerColor = Color(0xFF1E1E2E),
        shape = RoundedCornerShape(16.dp)
    )
}

// FlowLayout fallback implementation to keep from importing external complex layout systems
@Composable
fun FlowLayout(
    modifier: Modifier = Modifier,
    horizontalGap: androidx.compose.ui.unit.Dp = 8.dp,
    verticalGap: androidx.compose.ui.unit.Dp = 8.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(
        modifier = modifier,
        content = content
    ) { measurables, constraints ->
        val hGapPx = horizontalGap.roundToPx()
        val vGapPx = verticalGap.roundToPx()
        val placeables = measurables.map { it.measure(constraints.copy(minWidth = 0)) }

        val rows = mutableListOf<List<androidx.compose.ui.layout.Placeable>>()
        var currentRow = mutableListOf<androidx.compose.ui.layout.Placeable>()
        var currentRowWidth = 0

        placeables.forEach { placeable ->
            if (currentRowWidth + placeable.width + hGapPx > constraints.maxWidth && currentRow.isNotEmpty()) {
                rows.add(currentRow)
                currentRow = mutableListOf()
                currentRowWidth = 0
            }
            currentRow.add(placeable)
            currentRowWidth += placeable.width + hGapPx
        }
        if (currentRow.isNotEmpty()) {
            rows.add(currentRow)
        }

        var totalHeight = 0
        rows.forEachIndexed { idx, row ->
            val rowHeight = row.maxOfOrNull { it.height } ?: 0
            totalHeight += rowHeight
            if (idx < rows.size - 1) totalHeight += vGapPx
        }

        layout(constraints.maxWidth, totalHeight) {
            var y = 0
            rows.forEach { row ->
                var x = 0
                val rowHeight = row.maxOfOrNull { it.height } ?: 0
                row.forEach { placeable ->
                    placeable.placeRelative(x, y + (rowHeight - placeable.height) / 2)
                    x += placeable.width + hGapPx
                }
                y += rowHeight + vGapPx
            }
        }
    }
}
