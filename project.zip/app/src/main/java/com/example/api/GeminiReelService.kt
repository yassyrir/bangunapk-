package com.example.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.ReelEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object GeminiReelService {
    private const val TAG = "GeminiReelService"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Checks if the API key is configured and is not the default placeholder.
     */
    fun isApiKeyAvailable(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY" && key != "PLACEHOLDER"
    }

    /**
     * Generates a new Reel suggestions list based on a given topic/vibe.
     */
    suspend fun generateReel(topic: String): ReelItemResult = withContext(Dispatchers.IO) {
        if (!isApiKeyAvailable()) {
            Log.w(TAG, "Gemini API key is not configured. Falling back to offline bank.")
            return@withContext ReelItemResult.Fallback(getOfflineReel(topic), "API Key not configured in Secrets Panel.")
        }

        val prompt = """
            Generate 1 creative Android Reel suggestion in JSON format about the topic: "$topic".
            It must be extremely catchy, authentic, and styled like real modern social media captions.
            Use hashtags correctly.
            Return ONLY a valid JSON object matching this schema exactly, with NO markdown code blocks, backticks, or extra characters:
            {
               "username": "lowercase_handle_without_space_or_at",
               "description": "Engaging reel caption with relevant modern hashtags and emojis",
               "category": "Short text of the category (e.g. Kotlin, Fun, Motivation, Cooking)",
               "likes": 12503
            }
        """.trimIndent()

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            // Configure JSON response configuration to be safe
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url("${BASE_URL}v1beta/models/gemini-3.5-flash:generateContent?key=${BuildConfig.GEMINI_API_KEY}")
            .post(jsonRequest.toString().toRequestBody(mediaType))
            .build()

        try {
            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorMsg = "HTTP Error: ${response.code} ${response.message}"
                    Log.e(TAG, errorMsg)
                    return@withContext ReelItemResult.Fallback(getOfflineReel(topic), errorMsg)
                }

                val bodyStr = response.body?.string() ?: ""
                Log.d(TAG, "Gemini Raw Response: $bodyStr")

                val jsonResponse = JSONObject(bodyStr)
                val candidates = jsonResponse.getJSONArray("candidates")
                val text = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                // Trim text in case markdowns escaped
                val cleanJson = text.trim()
                    .removePrefix("```json")
                    .removePrefix("```")
                    .removeSuffix("```")
                    .trim()

                val obj = JSONObject(cleanJson)
                val generatedReel = ReelEntity(
                    username = obj.optString("username", "ai_creator").lowercase().replace(" ", ""),
                    description = obj.optString("description", "Just coded an awesome thing! ✨"),
                    likes = obj.optInt("likes", Random.nextInt(100, 5000)),
                    isLiked = false,
                    category = obj.optString("category", topic),
                    commentsCount = Random.nextInt(5, 120),
                    sharesCount = Random.nextInt(2, 45)
                )
                ReelItemResult.Success(generatedReel)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed calling Gemini API", e)
            ReelItemResult.Fallback(getOfflineReel(topic), "Network exception: ${e.localizedMessage}")
        }
    }

    /**
     * Generates a realistic set of comments based on the Reel description.
     */
    suspend fun generateComments(description: String): CommentsResult = withContext(Dispatchers.IO) {
        if (!isApiKeyAvailable()) {
            return@withContext CommentsResult.Fallback(getOfflineComments(description), "API Key not configured.")
        }

        val prompt = """
            Analyze this short-form video caption: "$description".
            Generate a list of 4 highly realistic social media comments in JSON array format.
            Each comment should match the caption's vibe (highly interactive, funny, or technical).
            Return ONLY a valid JSON array matching this schema exactly, with NO markdown code blocks, backticks, or extra characters:
            [
               {"username": "user1", "text": "Comment content with emoji", "likes": 42},
               {"username": "user2", "text": "Another typical short comment", "likes": 12}
            ]
        """.trimIndent()

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.8)
            })
        }

        val request = Request.Builder()
            .url("${BASE_URL}v1beta/models/gemini-3.5-flash:generateContent?key=${BuildConfig.GEMINI_API_KEY}")
            .post(jsonRequest.toString().toRequestBody(mediaType))
            .build()

        try {
            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext CommentsResult.Fallback(getOfflineComments(description), "HTTP error ${response.code}")
                }
                val bodyStr = response.body?.string() ?: ""
                val text = JSONObject(bodyStr)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val cleanJson = text.trim()
                    .removePrefix("```json")
                    .removePrefix("```")
                    .removeSuffix("```")
                    .trim()

                val arr = JSONArray(cleanJson)
                val list = mutableListOf<GeneratedComment>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        GeneratedComment(
                            username = obj.optString("username", "viewer_${Random.nextInt(100, 999)}").lowercase(),
                            text = obj.optString("text", "Awesome content! Double tap! ❤️"),
                            likes = obj.optInt("likes", Random.nextInt(2, 120))
                        )
                    )
                }
                CommentsResult.Success(list)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse generated comments", e)
            CommentsResult.Fallback(getOfflineComments(description), e.localizedMessage ?: "Unknown exception")
        }
    }

    private fun getOfflineReel(topic: String): ReelEntity {
        val handles = listOf("code_craft", "dev_bytes", "system_engineer", "pixel_master", "stack_overflow")
        val fallbackCaptions = listOf(
            "This custom offline topic: #$topic is actually pretty cool! Loving the flow here! 🌟 #offlineVibes #android",
            "Why do developers buy black laptops? Because they are easy to light up with custom IDE themes! 💻 Offline mood on #$topic.",
            "That face you make when the compiler works on the first try without warnings. 🛠️ #codingLife #$topic",
            "Building stunning native UI in a modern slate canvas. Simple, clean, robust. #$topic #uiux",
            "Nothing beats dynamic Material 3 and responsive gesture animations. #$topic #design #tech"
        )
        return ReelEntity(
            username = handles.random(),
            description = fallbackCaptions.random(),
            likes = Random.nextInt(150, 2030),
            isLiked = false,
            category = topic.ifEmpty { "General" },
            commentsCount = Random.nextInt(3, 15),
            sharesCount = Random.nextInt(1, 8)
        )
    }

    private fun getOfflineComments(description: String): List<GeneratedComment> {
        return listOf(
            GeneratedComment("compose_fan", "This is absolutely incredible! Thanks for sharing! 🔥", Random.nextInt(5, 50)),
            GeneratedComment("bug_hunter", "Wait, did you handle Edge-to-Edge insets correctly? It looks clean! 📱", Random.nextInt(2, 25)),
            GeneratedComment("dev_giggle", "Need this logic in production right away! 😂", Random.nextInt(1, 10)),
            GeneratedComment("design_wizard", "Stated visually solid. Love the color grading here! ✨", Random.nextInt(4, 15))
        )
    }
}

sealed interface ReelItemResult {
    data class Success(val reel: ReelEntity) : ReelItemResult
    data class Fallback(val reel: ReelEntity, val reason: String) : ReelItemResult
}

sealed interface CommentsResult {
    data class Success(val comments: List<GeneratedComment>) : CommentsResult
    data class Fallback(val comments: List<GeneratedComment>, val reason: String) : CommentsResult
}

data class GeneratedComment(
    val username: String,
    val text: String,
    val likes: Int
)
